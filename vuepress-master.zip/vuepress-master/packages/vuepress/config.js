module.exports = require('@vuepress/types')
