module.exports = require('@vuepress/core')
