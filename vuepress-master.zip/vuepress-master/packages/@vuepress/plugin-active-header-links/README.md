# @vuepress/plugin-active-header-links

> active-header-links plugin for VuePress

See [documentation](https://vuepress.vuejs.org/plugin/official/plugin-active-header-links.html).
