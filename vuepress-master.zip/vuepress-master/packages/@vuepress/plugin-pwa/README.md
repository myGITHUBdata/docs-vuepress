# @vuepress/plugin-pwa

> PWA plugin for VuePress

See [documentation](https://vuepress.vuejs.org/plugin/official/plugin-pwa.html).
