# @vuepress/plugin-register-components

> register-components plugin for VuePress

