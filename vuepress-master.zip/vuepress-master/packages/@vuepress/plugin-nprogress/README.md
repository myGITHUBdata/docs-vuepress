# @vuepress/plugin-nprogress

> nprogress plugin for VuePress
