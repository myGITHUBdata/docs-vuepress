# @vuepress/plugin-search

> header-based search plugin for VuePress

See [documentation](https://vuepress.vuejs.org/plugin/official/plugin-search.html).

