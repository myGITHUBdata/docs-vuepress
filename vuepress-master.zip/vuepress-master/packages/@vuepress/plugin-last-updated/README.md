# @vuepress/plugin-last-updated

> last-updated plugin for VuePress

See [documentation](https://vuepress.vuejs.org/plugin/official/plugin-last-updated.html).
