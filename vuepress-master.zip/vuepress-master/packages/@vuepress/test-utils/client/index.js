import createLocalVue from './createLocalVue'
import mockComponent from './mockComponent'

export {
  createLocalVue,
  mockComponent
}
