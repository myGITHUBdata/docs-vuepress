# @vuepress/plugin-medium-zoom

> medium-zoom plugin for VuePress

See [documentation](https://vuepress.vuejs.org/plugin/official/plugin-medium-zoom.html).
