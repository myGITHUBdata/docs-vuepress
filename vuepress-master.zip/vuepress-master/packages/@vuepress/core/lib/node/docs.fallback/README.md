# VuePress

> `Prompts`: You are running VuePress without setting sourceDir!
