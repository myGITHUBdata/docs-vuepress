<<< @/packages/@vuepress/markdown/__tests__/fragments/snippet with spaces.js {1-3}
