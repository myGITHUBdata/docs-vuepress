<<< @/packages/@vuepress/markdown/__tests__/fragments/snippet.js{1,3}
