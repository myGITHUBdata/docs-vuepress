# @vuepress/plugin-back-to-top

> Back-to-top plugin for VuePress

See [documentation](https://vuepress.vuejs.org/plugin/official/plugin-back-to-top.html).
