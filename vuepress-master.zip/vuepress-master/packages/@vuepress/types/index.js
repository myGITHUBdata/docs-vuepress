function define(config) {
  return config;
}
exports.defineConfig = define;
exports.defineConfig4CustomTheme = define;
exports.defineTheme = define;
exports.definePlugin = define;
