# Theme

::: tip
Theme components are under the same [browser API access restrictions](../guide/using-vue.md#browser-api-access-restrictions).
:::
