---
title: back-to-top
metaTitle: Back-To-Top Plugin | VuePress
---

# [@vuepress/plugin-back-to-top](https://github.com/vuejs/vuepress/tree/master/packages/%40vuepress/plugin-back-to-top)

> Back-to-top plugin

## Install

```bash
yarn add -D @vuepress/plugin-back-to-top
# OR npm install -D @vuepress/plugin-back-to-top
```

## Usage

```javascript
module.exports = {
  plugins: ['@vuepress/back-to-top']
}
```
