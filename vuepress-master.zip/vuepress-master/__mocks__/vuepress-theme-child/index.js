module.exports = {
  extend: 'vuepress-theme-parent'
}
